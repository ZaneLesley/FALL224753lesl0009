#' Lab Package
#'
#' contains functions from labs
#'
#' #docType package
#'
#' @author Zane Lesley \email{zanelesley@ou.edu}
#'
#' @name LabPackages
NULL
